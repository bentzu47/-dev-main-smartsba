<template>
    <div class="row mb-3">
        <slot/>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>