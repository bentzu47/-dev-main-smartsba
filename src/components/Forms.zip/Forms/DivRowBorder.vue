<template>
    <div class="row g-0 border p-3 pb-4 mb-3">
        <slot></slot>
    </div>
</template>